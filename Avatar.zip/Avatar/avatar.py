import sys, json, os, glob, time, traceback
import cv2, numpy as np, pyvirtualcam, sounddevice as sd
from scipy.linalg import solve_toeplitz
from scipy.signal import resample

# ---------- settings ----------
DEVICE = None                          # mic device ID from `python -m sounddevice` (None = default mic)
SR = 16000                             # internal analysis rate
WIN = 1024                             # analysis window (~64 ms)
FPS = 30
SILENCE = 0.008                        # minimum volume threshold (raised automatically if your room is noisier)
NOISE_MULT = 2.0                       # threshold = room noise level x this
MAX_THRESHOLD = 0.03                   # the auto threshold never goes above this
VOICED_MIN = 0.3                       # how clearly pitched a sound must be (0-1); lower = more lenient
HOLD = 0.2                             # seconds to keep the last vowel when the sound briefly drops out
SMOOTH = 3                             # vote over last N frames
CALIB_FILE = "calib.json"
MAX_NAME_LEN = 3                       # a.png, o.png, sh.png count; screenshot123.png doesn't
SHOW_PREVIEW = True                    # window named "avatar" for OBS Window Capture
DEBUG = True                           # prints volume/clarity a few times a second; set False when it works
# rough default (F1, F2 in Hz) for vowels with no calibration
DEFAULTS = {"a": (730, 1090), "e": (530, 1840), "i": (270, 2290),
            "o": (570, 840),  "u": (300, 870)}
# -------------------------------

# ---------- microphone ----------
def pick_capture_rate():
    """Use 16000 Hz if the mic accepts it, otherwise the mic's default rate."""
    try:
        sd.check_input_settings(device=DEVICE, channels=1, samplerate=SR)
        return SR
    except Exception:
        info = sd.query_devices(DEVICE, "input")
        return int(info["default_samplerate"])

CAP_SR = None                          # set in main()

def to_analysis_rate(x):
    """Convert a block captured at CAP_SR to SR."""
    if CAP_SR == SR:
        return x
    return resample(x, int(round(len(x) * SR / CAP_SR))).astype(np.float32)

def record(seconds):
    """Record from the mic and return audio at SR."""
    audio = sd.rec(int(seconds * CAP_SR), samplerate=CAP_SR, channels=1,
                   device=DEVICE, blocking=True)[:, 0]
    return to_analysis_rate(audio)

# ---------- analysis ----------
def formants(x):
    """Return (F1, F2) of a voiced block, or None."""
    x = x * np.hamming(len(x))
    x = np.append(x[0], x[1:] - 0.97 * x[:-1])          # pre-emphasis
    order = 12
    r = np.correlate(x, x, "full")[len(x) - 1:len(x) + order]
    if r[0] < 1e-9:
        return None
    try:
        a = solve_toeplitz(r[:order], r[1:order + 1])
    except Exception:
        return None
    roots = np.roots(np.concatenate(([1], -a)))
    roots = roots[np.imag(roots) > 0.01]
    freqs = np.angle(roots) * SR / (2 * np.pi)
    bws = -0.5 * (SR / (2 * np.pi)) * 2 * np.log(np.abs(roots))
    f = sorted(fr for fr, bw in zip(freqs, bws) if 90 < fr < 4500 and bw < 400)
    return (f[0], f[1]) if len(f) >= 2 else None

def rms(x):
    return float(np.sqrt(np.mean(x ** 2)))

def pitch_clarity(x):
    """0-1: how periodic the sound is. Voice/vowels are high, noise is low."""
    x = x - np.mean(x)
    n = len(x)
    r = np.correlate(x, x, "full")[n - 1:]
    if r[0] < 1e-9:
        return 0.0
    lo, hi = SR // 400, SR // 70                      # pitch range 70-400 Hz
    lags = np.arange(lo, hi)
    norm = (r[lo:hi] / (n - lags)) / (r[0] / n)       # fair comparison across lags
    return float(min(norm.max(), 1.0))

def found_sounds():
    """PNGs named like a sound (1-3 letters, no digits), except closed.png."""
    names = [os.path.splitext(os.path.basename(p))[0] for p in glob.glob("*.png")]
    return sorted(n for n in names
                  if n.lower() != "closed"
                  and n.isalpha()
                  and len(n) <= MAX_NAME_LEN)

def load_refs():
    refs = dict(DEFAULTS)
    if os.path.exists(CALIB_FILE):
        refs.update({k: tuple(v) for k, v in json.load(open(CALIB_FILE)).items()})
    else:
        print("No calib.json found, using default values. "
              "Run `python avatar.py calibrate` for better accuracy.")
    return refs

def classify(f1f2, refs):
    f1, f2 = np.log(f1f2)
    return min(refs, key=lambda s: (f1 - np.log(refs[s][0])) ** 2 +
                                    (f2 - np.log(refs[s][1])) ** 2)

def measure_noise():
    """Listen to the room for 1 second and return a volume threshold above it."""
    print("Measuring room noise, stay quiet for 1 second...")
    audio = record(1.0)
    levels = [rms(audio[i:i + WIN]) for i in range(0, len(audio) - WIN, WIN // 2)]
    noise = float(np.percentile(levels, 90)) if levels else 0.0
    threshold = min(MAX_THRESHOLD, max(SILENCE, noise * NOISE_MULT))
    print(f"  room noise {noise:.4f} -> silence threshold {threshold:.4f}")
    return threshold

# ---------- preview window ----------
def open_preview(frame):
    """Open the 'avatar' window right away. Returns True if it works."""
    try:
        cv2.namedWindow("avatar", cv2.WINDOW_NORMAL)
        cv2.imshow("avatar", cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
        cv2.waitKey(1)
        print("Preview window opened (look for a window titled 'avatar', check the taskbar).")
        return True
    except Exception as e:
        print("PREVIEW WINDOW FAILED:", e)
        print("Fix: pip uninstall opencv-python-headless opencv-python -y && pip install opencv-python")
        return False

# ---------- key input ----------
def get_key():
    """Read one key press without needing Enter."""
    if os.name == "nt":
        import msvcrt
        ch = msvcrt.getwch()
        if ch in ("\x00", "\xe0"):        # arrow/function keys send two codes
            msvcrt.getwch()
            return ""
    else:
        import termios, tty
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    if ch == "\x03":                      # Ctrl+C
        raise KeyboardInterrupt
    return ch

def wait_for_sound(name):
    """Wait until the key(s) for this sound are pressed. Esc skips it."""
    typed = ""
    while True:
        ch = get_key()
        if ch == "\x1b":
            return False
        typed = (typed + ch.lower())[-len(name):]
        if typed == name.lower():
            return True

# ---------- calibration ----------
def calibrate():
    sounds = found_sounds()
    if not sounds:
        sys.exit("No sound images found (e.g. a.png, o.png).")
    print("Found images for:", ", ".join(sounds))
    threshold = measure_noise()
    refs = {}
    if os.path.exists(CALIB_FILE):
        refs = {k: tuple(v) for k, v in json.load(open(CALIB_FILE)).items()}
    for s in sounds:
        print(f"\nPress '{s}' to record it (Esc to skip)... ", end="", flush=True)
        if not wait_for_sound(s):
            print("skipped")
            continue
        time.sleep(0.3)                   # let the key click fade out
        print(f"hold '{s}' now for 2 seconds...")
        audio = record(2.0)
        pts = []
        for i in range(0, len(audio) - WIN, WIN // 2):
            blk = audio[i:i + WIN]
            if rms(blk) > threshold and pitch_clarity(blk) > VOICED_MIN:
                f = formants(blk)
                if f:
                    pts.append(f)
        if not pts:
            print("  couldn't measure that, skipping (rerun and hold it louder/steadier)")
        else:
            refs[s] = tuple(np.median(pts, axis=0).tolist())
            print(f"  {s}: F1={refs[s][0]:.0f}  F2={refs[s][1]:.0f}")
    json.dump(refs, open(CALIB_FILE, "w"))
    print("\nSaved calib.json")

# ---------- main ----------
def run():
    print("Starting... (OpenCV", cv2.__version__ + ")")
    print("Working folder:", os.getcwd())
    refs = load_refs()
    closed = cv2.imread("closed.png")
    if closed is None:
        sys.exit("Missing closed.png (is this the right folder?)")
    closed = cv2.cvtColor(closed, cv2.COLOR_BGR2RGB)
    H, W = closed.shape[:2]

    imgs = {"closed": closed}
    for name in found_sounds():
        img = cv2.imread(f"{name}.png")
        if img is None:
            continue
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        if img.shape[:2] != (H, W):
            img = cv2.resize(img, (W, H))
        imgs[name] = img
    print("Loaded images:", ", ".join(imgs))

    # open the window first so you can see right away whether it works
    show_preview = open_preview(closed) if SHOW_PREVIEW else False

    threshold = measure_noise()

    # virtual camera is optional: if it fails, keep going with the preview window
    cam = None
    try:
        cam = pyvirtualcam.Camera(width=W, height=H, fps=FPS)
        print("Using virtual camera:", cam.device)
    except Exception as e:
        print("Virtual camera failed:", e)
        print("Continuing with the preview window only.")
        if not show_preview:
            show_preview = open_preview(closed)

    n_cap = int(WIN * CAP_SR / SR)          # samples of raw audio that make one analysis window
    buf = np.zeros(n_cap, np.float32)
    def cb(indata, frames, t, status):
        nonlocal buf
        buf = np.concatenate([buf, indata[:, 0]])[-n_cap:]

    history = []
    last_vowel = "closed"
    last_voiced = 0.0
    last_debug = 0.0
    with sd.InputStream(channels=1, samplerate=CAP_SR, blocksize=256,
                        device=DEVICE, callback=cb):
        print("Running. Ctrl+C to stop.")
        try:
            while True:
                now = time.time()
                block = to_analysis_rate(buf.copy())
                vol = rms(block)
                clarity = pitch_clarity(block) if vol >= threshold else 0.0

                if vol >= threshold and clarity >= VOICED_MIN:
                    last_voiced = now
                    f = formants(block)
                    if f:
                        last_vowel = classify(f, refs)
                    guess = last_vowel                        # no formants -> keep previous vowel
                elif now - last_voiced < HOLD:
                    guess = last_vowel                        # brief dropout, keep showing it
                else:
                    guess = "closed"
                    last_vowel = "closed"

                if DEBUG and now - last_debug > 0.25:
                    print(f"vol={vol:.4f} (min {threshold:.4f})  clarity={clarity:.2f} (min {VOICED_MIN})  -> {guess}")
                    last_debug = now

                history = (history + [guess])[-SMOOTH:]
                shown = max(set(history), key=history.count)   # majority vote
                frame = imgs.get(shown, closed)                # missing image -> closed
                if cam:
                    cam.send(frame)
                if show_preview:
                    cv2.imshow("avatar", cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
                    cv2.waitKey(1)
                if cam:
                    cam.sleep_until_next_frame()
                else:
                    time.sleep(1 / FPS)
        except KeyboardInterrupt:
            pass
        finally:
            if cam:
                cam.close()
            cv2.destroyAllWindows()

def main():
    global CAP_SR
    CAP_SR = pick_capture_rate()
    print(f"Mic capture rate: {CAP_SR} Hz")
    if len(sys.argv) > 1 and sys.argv[1] == "calibrate":
        calibrate()
    else:
        run()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except BaseException:
        traceback.print_exc()
        input("\nSomething went wrong (error above). Press Enter to close...")